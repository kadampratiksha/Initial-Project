<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RestaurantImage extends Model
{
    public $primaryKey = 'restaurant_image_id';
}
